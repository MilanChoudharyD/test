import React from 'react'

const EditModal = () => {
  return (
    <div>
      
    </div>
  )
}

export default EditModal
