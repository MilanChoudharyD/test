import React from 'react'
import { TextField, Autocomplete  } from "@mui/material";
// import SearchIcon from "@mui/icons-material/Search";

const top100Films = [
  { label: 'Pappu' },
  { label: 'Lala' },
  { label: 'Babu'},
  { label: 'Fati fall' },
]
const SearchInput = () => {
  return (
    <div>
          <Autocomplete
            size="small"
            disablePortal
            options={top100Films}
            sx={{ width: 300 }}
            renderInput={(params) => <TextField {...params} label="User List" />}
          />
  </div>
  )
}

export default SearchInput