import { react, useState } from 'react';
import { styled } from '@mui/material/styles';
import TablePagination from '@mui/material/TablePagination';
import {Avatar } from '@mui/material';
// import CloseIcon from "@mui/icons-material/Close";

import {
  Box, Button, Stack,Table, TableBody, 
  TableCell, TableContainer, TableHead, 
  TableRow, Paper,tableCellClasses, IconButton, Modal, Typography,Tabs,Tab,AppBar, TextField
} 
from '@mui/material';
import EditModal from '../editModal/EditModal';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein };
}

const rows = [
  createData('qqq', 'Pappu', 9988774455, 24, 4.0),
  createData('www', 'Lala', 1234567897, 37, 4.3),
  createData('wwwe', 'Babu', 7878787877, 24, 6.0),
  createData('werw', 'Jitu', 1111111111, 67, 4.3),
  createData('12ggrg', 'Pratik Kukreja', 420420420420, 49, 3.9),
  createData('ewer3fwe', 320, 12.0, 40, 5.0),
  createData('tw4t4t3', 400, 18.0, 50, 6.5),
  createData('tgwgr', 250, 10.0, 35, 3.0),
  createData('wgwg', 450, 22.0, 60, 4.2),
  createData('wrgwgw', 290, 8.0, 45, 4.1),
];
const UserTable = () => {

    const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
    const [open, setOpen] = useState(false);
  
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <>
        <TableContainer component={Paper}>
      <Table size="small" sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell>Client ID</StyledTableCell>
            <StyledTableCell align="right">Name</StyledTableCell>
            <StyledTableCell align="right">Number</StyledTableCell>
            <StyledTableCell align="right">Action</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => (
            <StyledTableRow key={row.name}>
              <StyledTableCell component="th" scope="row">
                {row.name}
              </StyledTableCell>
              <StyledTableCell align="right">{row.calories}</StyledTableCell>
              <StyledTableCell align="right">{row.fat}</StyledTableCell>
              <StyledTableCell align="right">
                <Stack   direction="row"  spacing={{ xs: 1, sm: 2 }} sx={{display:'flex', justifyContent:'end'}}>
                <Button onClick={handleOpen} variant="contained">Edit</Button>
              <Button variant="contained">Delete</Button>
              </Stack></StyledTableCell>

            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
      <TablePagination
        rowsPerPageOptions={[5, 10, 15]}
        component="div"
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </TableContainer>

    <Box>
    <Modal  open={open} onClose={handleClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 800,
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 1,
            borderRadius: 2,
          }}
        >
          {/* Close Button */}
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              position: "absolute",
              top: 8,
              right: 8,
            }}
          >
            {/* <CloseIcon /> */}
            X
          </IconButton>

          <Box>
          <Box sx={{ width: '100%', bgcolor: "background.paper" }}>
      <AppBar position="static">
        <Tabs className='tab_select' value={value} onChange={handleChange} variant="fullWidth">
          <Tab className='Edit_tab' label="Profile" />
          <Tab className='Edit_tab' label="Bank Details" />
          <Tab className='Edit_tab' label="Trading Summary" />
          <Tab className='Edit_tab' label="Service Fee" />
        </Tabs>
      </AppBar>

      <Box sx={{ p: 3 }}>
        {value === 0 && 
        <Stack direction="column" className='' >
          <Stack sx={{borderRadius:'100%', width:'100%', justifyContent: "center" }}  direction="row" spacing={2}>
            {/* <Avatar
              alt="Remy Sharp"
              src="/static/images/avatar/1.jpg"
              sx={{ width: 100, height: 100 }}
            /> */}
            <img className='avatar_img' src="../../images/WhatsApp Image 2025-03-09 at 11.59.06 PM.jpeg" style={{width:'150px', height:'150px'}} alt="" />
          </Stack>
          <Box sx={{gap:'1rem', display:'flex', width:'100%'}} className=''>
              <TextField
                size='small'
                label="Client ID"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
              <TextField
              size='small'
              label="Name"
              variant="outlined" // Can be "filled" or "standard"
              fullWidth
              margin="normal"
              />
          </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>  
               
               <TextField
                size='small'
                label="Password"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
               <TextField
                size='small'
                label="Phone Number"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
            </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>
            <TextField
                size='small'
                label="PAN Number"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
               <TextField
                size='small'
                label="Account Opening Date"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
            </Box>
            <Box sx={{mt:2}}>
            <Button variant="contained">DONE</Button>
            </Box>
        </Stack>
        }
        {value === 1 && 
        <Stack direction="column" className='' >
          <Box>
          <img className='' src="../../images/bank.png" style={{width:'60px'}} alt="" />
          </Box>
          <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>  
               <TextField
                size='small'
                label="A/C Holder Name"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
               <TextField
                size='small'
                label="Account Number"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
            </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>
            <TextField
                size='small'
                label="IFCS Code"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
               <TextField
                size='small'
                label="Bank Name"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
            </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>
            <TextField
                size='small'
                label="Branch Name"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
               />
            </Box>
            <Box sx={{mt:2}}>
            <Button variant="contained">DONE</Button>
            </Box>
        </Stack>
        }
        {value === 2 && 
        <Stack direction="column" className='' >
          <Box>
          <img className='' src="../../images/chart.png" style={{width:'60px'}} alt="" />
          </Box>
          <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>  
              <TextField
                size='small'
                label="Funds Allocated"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
              />
              <TextField
                size='small'
                label="Account Number"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
              />
            </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>
            <TextField
                size='small'
                label="IFCS Code"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
              />
              <TextField
                size='small'
                label="Bank Name"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
              />
            </Box>
            <Box  sx={{gap:'1rem', display:'flex', width:'100%'}}>
            <TextField
                size='small'
                label="Branch Name"
                variant="outlined" // Can be "filled" or "standard"
                fullWidth
                margin="normal"
              />
            </Box>
            <Box sx={{mt:2}}>
            <Button variant="contained">DONE</Button>
            </Box>
        </Stack>

        }
        {value === 3 && <Typography>Item Four</Typography>}
      </Box>
    </Box>
          </Box>
        </Box>
      </Modal>


    </Box>
    </>
  )
}

export default UserTable