import React from 'react'
// import logo from './logo.svg';
import './App.css';
import { Box, Typography } from '@mui/material';
import SearchInput from './Component/search/SearchInput';
import UserTable from './Component/Table/UserTable';
import "../src/css/custom.css"

function App() {
  return (
    <Box className="App" sx={{p:2}}>
      <header className="App-header">
        <Box sx={{display:'flex', justifyContent: "space-between",}}>

        <Typography variant="h5" component="h5">
            User List
        </Typography>
        <div>
          <SearchInput/>
        </div>
        </Box>
      </header>
      <Box></Box>
      <Box sx={{pt:3}}>
        <UserTable/>
      </Box>
    </Box>
  );
}

export default App;
