import React from 'react'

const tradingSummary = () => {
  return (
    <div>tradingSummary</div>
  )
}

export default tradingSummary