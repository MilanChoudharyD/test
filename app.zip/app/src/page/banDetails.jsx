import React from 'react'

const banDetails = () => {
  return (
    <div>banDetails</div>
  )
}

export default banDetails