import React from 'react'

const serviceFee = () => {
  return (
    <div>serviceFee</div>
  )
}

export default serviceFee